var levels_8h =
[
    [ "display_level", "levels_8h.html#a1b071eae4f08a6292ae2704a9f143b71", null ],
    [ "level_checkCollision", "levels_8h.html#af373dd192df9166162888aff8d2eb836", null ],
    [ "level_checkInput", "levels_8h.html#ace709168861a37d3cdb47c0e45fb4908", null ],
    [ "level_createSprites", "levels_8h.html#a8120372d3f9fd0d09820305f131135b7", null ],
    [ "level_run", "levels_8h.html#a94f7663bad56c5069d33de816fbf571b", null ],
    [ "level_updateFrame", "levels_8h.html#aff1d9205a942c539b0fa0fe84cd55743", null ]
];