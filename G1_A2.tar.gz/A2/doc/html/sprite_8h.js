var sprite_8h =
[
    [ "sprite", "structsprite.html", "structsprite" ],
    [ "sprite_changeVel", "sprite_8h.html#afd6ddfc176b080172146eeb6ee3bed87", null ],
    [ "sprite_createEnemy", "sprite_8h.html#ae94fa8125b1db6fefed7c53c9247d867", null ],
    [ "sprite_createPlayer", "sprite_8h.html#a9ebe044eb55190daa81aaf08f41d1fd2", null ],
    [ "sprite_move", "sprite_8h.html#a299ac5dc7eee291af612a6aa2d4abbc5", null ],
    [ "sprite_reset", "sprite_8h.html#a1a774dcb086ee4fefb9bfbe2813d7171", null ]
];