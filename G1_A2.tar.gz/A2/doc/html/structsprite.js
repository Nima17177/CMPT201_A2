var structsprite =
[
    [ "life", "structsprite.html#a6e202a80b413bf0dbb7f9f2c12d59959", null ],
    [ "symbol", "structsprite.html#abd104b908b86990a86087f2c66446400", null ],
    [ "tile", "structsprite.html#a7ba75436906c4a6cdb53257dbad57816", null ],
    [ "xPos", "structsprite.html#a212b658c0caccc29d627023e3cecf7cc", null ],
    [ "xVel", "structsprite.html#a52fc9542b49df017fc37350c66a92a46", null ],
    [ "yPos", "structsprite.html#a7bec3b0f98c5e2dfec918130b457638b", null ],
    [ "yVel", "structsprite.html#af63ad062f5f0b270efe5732a58564efa", null ]
];