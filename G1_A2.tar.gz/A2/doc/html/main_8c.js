var main_8c =
[
    [ "SPLASHFILE", "main_8c.html#a9210334c367aeb3f7a2e2599f33e0fa1", null ],
    [ "main", "main_8c.html#a840291bc02cba5474a4cb46a9b9566fe", null ],
    [ "readFile", "main_8c.html#a7c0605f5e36dd8804660051439659706", null ],
    [ "splashPage", "main_8c.html#a546caea94b22493cea275a0b5d1380bd", null ]
];