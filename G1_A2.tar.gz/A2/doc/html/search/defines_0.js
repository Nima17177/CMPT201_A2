var searchData=
[
  ['max_5fx',['MAX_X',['../map_8h.html#a898606140dee9ce0adf096de00824d94',1,'map.h']]],
  ['max_5fy',['MAX_Y',['../map_8h.html#a985cc18be96dda7f59fd0400725e4aef',1,'map.h']]]
];
