var searchData=
[
  ['ypos',['yPos',['../structsprite.html#a7bec3b0f98c5e2dfec918130b457638b',1,'sprite']]],
  ['yvel',['yVel',['../structsprite.html#af63ad062f5f0b270efe5732a58564efa',1,'sprite']]]
];
