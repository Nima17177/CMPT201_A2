var searchData=
[
  ['readfile',['readFile',['../main_8c.html#a7c0605f5e36dd8804660051439659706',1,'main.c']]]
];
