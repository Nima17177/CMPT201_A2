var searchData=
[
  ['splashpage',['splashPage',['../main_8c.html#a546caea94b22493cea275a0b5d1380bd',1,'main.c']]],
  ['sprite_5fchangevel',['sprite_changeVel',['../sprite_8h.html#afd6ddfc176b080172146eeb6ee3bed87',1,'sprite.h']]],
  ['sprite_5fcreateenemy',['sprite_createEnemy',['../sprite_8h.html#ae94fa8125b1db6fefed7c53c9247d867',1,'sprite.h']]],
  ['sprite_5fcreateplayer',['sprite_createPlayer',['../sprite_8h.html#a9ebe044eb55190daa81aaf08f41d1fd2',1,'sprite.h']]],
  ['sprite_5fmove',['sprite_move',['../sprite_8h.html#a299ac5dc7eee291af612a6aa2d4abbc5',1,'sprite.h']]],
  ['sprite_5freset',['sprite_reset',['../sprite_8h.html#a1a774dcb086ee4fefb9bfbe2813d7171',1,'sprite.h']]]
];
