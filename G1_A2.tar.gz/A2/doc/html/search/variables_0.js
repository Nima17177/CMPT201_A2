var searchData=
[
  ['life',['life',['../structsprite.html#a6e202a80b413bf0dbb7f9f2c12d59959',1,'sprite']]]
];
