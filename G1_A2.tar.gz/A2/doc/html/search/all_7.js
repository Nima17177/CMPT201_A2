var searchData=
[
  ['xpos',['xPos',['../structsprite.html#a212b658c0caccc29d627023e3cecf7cc',1,'sprite']]],
  ['xvel',['xVel',['../structsprite.html#a52fc9542b49df017fc37350c66a92a46',1,'sprite']]]
];
