var searchData=
[
  ['origin_5fx',['ORIGIN_X',['../map_8h.html#a801b4a8dae587b94276d327d6462baf4',1,'map.h']]],
  ['origin_5fy',['ORIGIN_Y',['../map_8h.html#a8b847faaa49e47547adafd822c75eea7',1,'map.h']]]
];
