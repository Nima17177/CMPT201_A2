var searchData=
[
  ['splashfile',['SPLASHFILE',['../main_8c.html#a9210334c367aeb3f7a2e2599f33e0fa1',1,'main.c']]]
];
