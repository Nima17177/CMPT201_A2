var files_dup =
[
    [ "levels.h", "levels_8h.html", "levels_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "map.h", "map_8h.html", "map_8h" ],
    [ "sprite.h", "sprite_8h.html", "sprite_8h" ]
];